# Breakdance Crew Website - Contrats API & Intégration

## Vue d'ensemble
Site web full-stack pour un crew de breakdance avec panel d'administration.

## Stack Technique
- **Frontend**: React + Tailwind CSS + shadcn/ui
- **Backend**: FastAPI + Python
- **Base de données**: MongoDB
- **Authentification**: JWT

---

## 1. DONNÉES MOCKÉES (frontend/src/mock.js)

### Actuellement mocké :
- `navItems`: Navigation du site
- `heroContent`: Contenu section héro (titre, sous-titre, CTAs)
- `features`: 3 cartes "Pourquoi nous choisir"
- `events`: Liste des événements
- `teamMembers`: Membres de l'équipe
- `communitySection`: Section CTA communauté

---

## 2. CONTRATS API BACKEND

### 2.1 Authentification Admin

#### POST /api/admin/login
```json
Request:
{
  "username": "admin",
  "password": "motdepasse"
}

Response:
{
  "access_token": "eyJ...",
  "token_type": "bearer"
}
```

#### GET /api/admin/verify
Headers: `Authorization: Bearer {token}`
```json
Response:
{
  "valid": true,
  "username": "admin"
}
```

---

### 2.2 Gestion des Événements

#### GET /api/events
```json
Response:
[
  {
    "_id": "...",
    "title": "Battle des Élèves",
    "date": "12 Déc 2025",
    "location": "Salle de l'Alagnier",
    "description": "Breaking 3vs3 Junior...",
    "imageUrl": "https://...",
    "featured": true,
    "createdAt": "2025-01-10T..."
  }
]
```

#### POST /api/events (Protégé - Admin)
Headers: `Authorization: Bearer {token}`
```json
Request:
{
  "title": "Nouveau Battle",
  "date": "15 Jan 2026",
  "location": "Centre Culturel",
  "description": "Description...",
  "imageUrl": "https://...",
  "featured": false
}

Response:
{
  "_id": "...",
  "title": "Nouveau Battle",
  ...
}
```

#### PUT /api/events/{event_id} (Protégé - Admin)
Headers: `Authorization: Bearer {token}`
```json
Request: (mêmes champs que POST)
Response: (événement mis à jour)
```

#### DELETE /api/events/{event_id} (Protégé - Admin)
Headers: `Authorization: Bearer {token}`
```json
Response:
{
  "message": "Événement supprimé avec succès"
}
```

---

### 2.3 Gestion du Contenu du Site

#### GET /api/site-content
```json
Response:
{
  "_id": "site_content_singleton",
  "heroTitle": "BREAKDANCE CREW",
  "heroSubtitle": "Passion, Énergie, Culture",
  "heroPrimaryCTA": "Découvrir nos événements",
  "heroSecondaryCTA": "Voir les vidéos",
  "communityTitle": "Rejoignez Notre Communauté",
  "communityDescription": "Que vous soyez débutant...",
  "communityCTA": "Contactez-nous",
  "features": [
    {
      "title": "Équipe Passionnée",
      "description": "Des danseurs professionnels...",
      "icon": "users"
    }
  ]
}
```

#### PUT /api/site-content (Protégé - Admin)
Headers: `Authorization: Bearer {token}`
```json
Request: (mêmes champs que GET)
Response: (contenu mis à jour)
```

---

## 3. MODÈLES MONGODB

### Collection: `events`
```python
{
  "_id": ObjectId,
  "title": str,
  "date": str,
  "location": str,
  "description": str,
  "imageUrl": str,
  "featured": bool,
  "createdAt": datetime
}
```

### Collection: `site_content` (document unique)
```python
{
  "_id": "site_content_singleton",
  "heroTitle": str,
  "heroSubtitle": str,
  "heroPrimaryCTA": str,
  "heroSecondaryCTA": str,
  "communityTitle": str,
  "communityDescription": str,
  "communityCTA": str,
  "features": [
    {
      "title": str,
      "description": str,
      "icon": str
    }
  ]
}
```

### Collection: `admin_users`
```python
{
  "_id": ObjectId,
  "username": str,
  "hashed_password": str,
  "createdAt": datetime
}
```

---

## 4. INTÉGRATION FRONTEND-BACKEND

### Étapes d'intégration :

1. **Supprimer les imports de mock.js** dans les composants
2. **Créer `/app/frontend/src/api/api.js`** avec fonctions API
3. **Remplacer les données statiques** par des appels API avec `useEffect`
4. **Créer le panel admin** `/admin` avec :
   - Page de login
   - Dashboard de gestion des événements
   - Éditeur de contenu du site
   - Protection par JWT

---

## 5. ROUTES FRONTEND

- `/` - Site public
- `/admin` - Page de login admin
- `/admin/dashboard` - Dashboard admin
- `/admin/events` - Gestion événements
- `/admin/content` - Gestion contenu site

---

## 6. SÉCURITÉ

- Mots de passe hashés avec `bcrypt`
- Tokens JWT expiration 24h
- Routes admin protégées backend
- Context React pour authentification frontend
- LocalStorage pour persistance token

---

## 7. PROCHAINES ÉTAPES

1. Implémenter les modèles MongoDB
2. Créer les routes API backend
3. Créer les utilitaires API frontend
4. Remplacer mock.js par appels API
5. Construire panel admin
6. Tester toutes les fonctionnalités
