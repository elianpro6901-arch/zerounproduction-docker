#!/usr/bin/env python3
"""
Backend API Testing for Breakdance Crew Website
Tests all backend endpoints including authentication and CRUD operations
"""

import requests
import json
import sys
from datetime import datetime

# Configuration
BACKEND_URL = "https://zerodance.preview.emergentagent.com/api"
DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "admin123"

class BackendTester:
    def __init__(self):
        self.base_url = BACKEND_URL
        self.token = None
        self.test_results = []
        
    def log_test(self, test_name, success, message, details=None):
        """Log test results"""
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status}: {test_name} - {message}")
        if details and not success:
            print(f"   Details: {details}")
    
    def test_health_check(self):
        """Test basic API health check by testing events endpoint"""
        try:
            # Test with events endpoint since root endpoint seems to have routing issues
            response = requests.get(f"{self.base_url}/events", timeout=10)
            if response.status_code == 200:
                self.log_test("Health Check", True, "API is running (tested via events endpoint)")
                return True
            else:
                self.log_test("Health Check", False, f"Unexpected status code: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Check", False, f"Connection failed: {str(e)}")
            return False
    
    def test_admin_login(self):
        """Test admin login endpoint"""
        try:
            # Test with correct credentials
            login_data = {
                "username": DEFAULT_ADMIN_USERNAME,
                "password": DEFAULT_ADMIN_PASSWORD
            }
            
            response = requests.post(
                f"{self.base_url}/admin/login",
                data=login_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "access_token" in data and "token_type" in data:
                    self.token = data["access_token"]
                    self.log_test("Admin Login", True, "Login successful, token received")
                    return True
                else:
                    self.log_test("Admin Login", False, "Token not found in response", data)
                    return False
            else:
                self.log_test("Admin Login", False, f"Login failed with status {response.status_code}", response.text)
                return False
                
        except Exception as e:
            self.log_test("Admin Login", False, f"Login request failed: {str(e)}")
            return False
    
    def test_admin_login_invalid_credentials(self):
        """Test admin login with invalid credentials"""
        try:
            login_data = {
                "username": "wrong_user",
                "password": "wrong_password"
            }
            
            response = requests.post(
                f"{self.base_url}/admin/login",
                data=login_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10
            )
            
            if response.status_code == 401:
                self.log_test("Admin Login (Invalid Credentials)", True, "Correctly rejected invalid credentials")
                return True
            else:
                self.log_test("Admin Login (Invalid Credentials)", False, f"Expected 401, got {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("Admin Login (Invalid Credentials)", False, f"Request failed: {str(e)}")
            return False
    
    def test_token_verification(self):
        """Test token verification endpoint"""
        if not self.token:
            self.log_test("Token Verification", False, "No token available for testing")
            return False
            
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.get(f"{self.base_url}/admin/verify", headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if "username" in data:
                    self.log_test("Token Verification", True, f"Token verified for user: {data['username']}")
                    return True
                else:
                    self.log_test("Token Verification", False, "Username not found in response", data)
                    return False
            else:
                self.log_test("Token Verification", False, f"Verification failed with status {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("Token Verification", False, f"Verification request failed: {str(e)}")
            return False
    
    def test_get_events(self):
        """Test GET /api/events endpoint (public)"""
        try:
            response = requests.get(f"{self.base_url}/events", timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if isinstance(data, list):
                    self.log_test("GET Events", True, f"Retrieved {len(data)} events")
                    return True, data
                else:
                    self.log_test("GET Events", False, "Response is not a list", data)
                    return False, None
            else:
                self.log_test("GET Events", False, f"Request failed with status {response.status_code}")
                return False, None
                
        except Exception as e:
            self.log_test("GET Events", False, f"Request failed: {str(e)}")
            return False, None
    
    def test_create_event(self):
        """Test POST /api/events endpoint (admin protected)"""
        if not self.token:
            self.log_test("POST Event", False, "No token available for testing")
            return False, None
            
        try:
            event_data = {
                "title": "Test Event - Battle de Rue",
                "date": "15 Jan 2026",
                "location": "Place de la République",
                "description": "Un battle de breakdance organisé pour tester l'API. Venez nombreux!",
                "imageUrl": "https://example.com/test-image.jpg",
                "featured": True
            }
            
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.post(
                f"{self.base_url}/events",
                json=event_data,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "id" in data and data["title"] == event_data["title"]:
                    self.log_test("POST Event", True, f"Event created with ID: {data['id']}")
                    return True, data["id"]
                else:
                    self.log_test("POST Event", False, "Event creation response invalid", data)
                    return False, None
            else:
                self.log_test("POST Event", False, f"Event creation failed with status {response.status_code}", response.text)
                return False, None
                
        except Exception as e:
            self.log_test("POST Event", False, f"Event creation request failed: {str(e)}")
            return False, None
    
    def test_create_event_without_token(self):
        """Test POST /api/events without authentication"""
        try:
            event_data = {
                "title": "Unauthorized Test Event",
                "date": "15 Jan 2026",
                "location": "Test Location",
                "description": "This should fail",
                "imageUrl": "https://example.com/test.jpg",
                "featured": False
            }
            
            response = requests.post(
                f"{self.base_url}/events",
                json=event_data,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 401:
                self.log_test("POST Event (No Auth)", True, "Correctly rejected unauthorized request")
                return True
            else:
                self.log_test("POST Event (No Auth)", False, f"Expected 401, got {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("POST Event (No Auth)", False, f"Request failed: {str(e)}")
            return False
    
    def test_update_event(self, event_id):
        """Test PUT /api/events/{event_id} endpoint"""
        if not self.token:
            self.log_test("PUT Event", False, "No token available for testing")
            return False
            
        if not event_id:
            self.log_test("PUT Event", False, "No event ID available for testing")
            return False
            
        try:
            update_data = {
                "title": "Updated Test Event - Battle Modifié",
                "description": "Description mise à jour pour tester l'API PUT"
            }
            
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.put(
                f"{self.base_url}/events/{event_id}",
                json=update_data,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if data["title"] == update_data["title"]:
                    self.log_test("PUT Event", True, f"Event {event_id} updated successfully")
                    return True
                else:
                    self.log_test("PUT Event", False, "Event update response invalid", data)
                    return False
            else:
                self.log_test("PUT Event", False, f"Event update failed with status {response.status_code}", response.text)
                return False
                
        except Exception as e:
            self.log_test("PUT Event", False, f"Event update request failed: {str(e)}")
            return False
    
    def test_update_nonexistent_event(self):
        """Test PUT /api/events/{event_id} with non-existent ID"""
        if not self.token:
            self.log_test("PUT Event (Not Found)", False, "No token available for testing")
            return False
            
        try:
            fake_id = "nonexistent-event-id-12345"
            update_data = {"title": "This should fail"}
            
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.put(
                f"{self.base_url}/events/{fake_id}",
                json=update_data,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 404:
                self.log_test("PUT Event (Not Found)", True, "Correctly returned 404 for non-existent event")
                return True
            else:
                self.log_test("PUT Event (Not Found)", False, f"Expected 404, got {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("PUT Event (Not Found)", False, f"Request failed: {str(e)}")
            return False
    
    def test_delete_event(self, event_id):
        """Test DELETE /api/events/{event_id} endpoint"""
        if not self.token:
            self.log_test("DELETE Event", False, "No token available for testing")
            return False
            
        if not event_id:
            self.log_test("DELETE Event", False, "No event ID available for testing")
            return False
            
        try:
            headers = {"Authorization": f"Bearer {self.token}"}
            
            response = requests.delete(
                f"{self.base_url}/events/{event_id}",
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if "message" in data:
                    self.log_test("DELETE Event", True, f"Event {event_id} deleted successfully")
                    return True
                else:
                    self.log_test("DELETE Event", False, "Delete response invalid", data)
                    return False
            else:
                self.log_test("DELETE Event", False, f"Event deletion failed with status {response.status_code}", response.text)
                return False
                
        except Exception as e:
            self.log_test("DELETE Event", False, f"Event deletion request failed: {str(e)}")
            return False
    
    def test_delete_nonexistent_event(self):
        """Test DELETE /api/events/{event_id} with non-existent ID"""
        if not self.token:
            self.log_test("DELETE Event (Not Found)", False, "No token available for testing")
            return False
            
        try:
            fake_id = "nonexistent-event-id-67890"
            headers = {"Authorization": f"Bearer {self.token}"}
            
            response = requests.delete(
                f"{self.base_url}/events/{fake_id}",
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 404:
                self.log_test("DELETE Event (Not Found)", True, "Correctly returned 404 for non-existent event")
                return True
            else:
                self.log_test("DELETE Event (Not Found)", False, f"Expected 404, got {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("DELETE Event (Not Found)", False, f"Request failed: {str(e)}")
            return False
    
    def test_get_site_content(self):
        """Test GET /api/site-content endpoint (public)"""
        try:
            response = requests.get(f"{self.base_url}/site-content", timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                required_fields = ["heroTitle", "heroSubtitle", "features"]
                if all(field in data for field in required_fields):
                    self.log_test("GET Site Content", True, "Site content retrieved successfully")
                    return True, data
                else:
                    missing = [f for f in required_fields if f not in data]
                    self.log_test("GET Site Content", False, f"Missing required fields: {missing}", data)
                    return False, None
            else:
                self.log_test("GET Site Content", False, f"Request failed with status {response.status_code}")
                return False, None
                
        except Exception as e:
            self.log_test("GET Site Content", False, f"Request failed: {str(e)}")
            return False, None
    
    def test_update_site_content(self):
        """Test PUT /api/site-content endpoint (admin protected)"""
        if not self.token:
            self.log_test("PUT Site Content", False, "No token available for testing")
            return False
            
        try:
            # First get current content to preserve structure
            get_success, current_content = self.test_get_site_content()
            if not get_success:
                self.log_test("PUT Site Content", False, "Could not retrieve current site content")
                return False
            
            # Update with new test data (all fields)
            updated_content = {
                "heroTitle": "Titre Héro Mis à Jour - Test API",
                "heroSubtitle": "Sous-titre mis à jour pour tester l'API PUT",
                "features": [
                    {
                        "title": "Feature Test 1",
                        "description": "Description de test mise à jour",
                        "icon": "🎯"
                    },
                    {
                        "title": "Feature Test 2", 
                        "description": "Deuxième feature de test",
                        "icon": "🚀"
                    }
                ]
            }
            
            headers = {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json"
            }
            
            response = requests.put(
                f"{self.base_url}/site-content",
                json=updated_content,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if (data["heroTitle"] == updated_content["heroTitle"] and 
                    data["heroSubtitle"] == updated_content["heroSubtitle"] and
                    len(data["features"]) == len(updated_content["features"])):
                    self.log_test("PUT Site Content", True, "Site content updated successfully")
                    
                    # Verify changes persist by getting content again
                    import time
                    time.sleep(1)  # Brief delay to ensure update is processed
                    verify_success, verify_data = self.test_get_site_content()
                    if verify_success and verify_data["heroTitle"] == updated_content["heroTitle"]:
                        self.log_test("PUT Site Content - Persistence", True, "Updated content persists correctly")
                        return True
                    else:
                        self.log_test("PUT Site Content - Persistence", False, "Updated content does not persist")
                        return False
                else:
                    self.log_test("PUT Site Content", False, "Site content update response invalid", data)
                    return False
            else:
                self.log_test("PUT Site Content", False, f"Site content update failed with status {response.status_code}", response.text)
                return False
                
        except Exception as e:
            self.log_test("PUT Site Content", False, f"Site content update request failed: {str(e)}")
            return False
    
    def test_update_site_content_without_token(self):
        """Test PUT /api/site-content without authentication"""
        try:
            update_data = {
                "heroTitle": "This should fail",
                "heroSubtitle": "Unauthorized update attempt"
            }
            
            response = requests.put(
                f"{self.base_url}/site-content",
                json=update_data,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 401:
                self.log_test("PUT Site Content (No Auth)", True, "Correctly rejected unauthorized request")
                return True
            else:
                self.log_test("PUT Site Content (No Auth)", False, f"Expected 401, got {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("PUT Site Content (No Auth)", False, f"Request failed: {str(e)}")
            return False
    
    def run_all_tests(self):
        """Run all backend tests in sequence"""
        print("🚀 Starting Backend API Tests for Breakdance Crew Website")
        print("=" * 60)
        
        # Test 1: Health check
        if not self.test_health_check():
            print("❌ Health check failed - stopping tests")
            return self.generate_summary()
        
        # Test 2: Admin authentication
        if not self.test_admin_login():
            print("❌ Admin login failed - some tests will be skipped")
        
        # Test 3: Invalid login
        self.test_admin_login_invalid_credentials()
        
        # Test 4: Token verification
        if self.token:
            self.test_token_verification()
        
        # Test 5: Get events (public)
        success, events = self.test_get_events()
        
        # Test 6: Create event (protected)
        success, created_event_id = self.test_create_event()
        
        # Test 7: Create event without auth
        self.test_create_event_without_token()
        
        # Test 8: Update event (protected)
        if created_event_id:
            self.test_update_event(created_event_id)
        
        # Test 9: Update non-existent event
        self.test_update_nonexistent_event()
        
        # Test 10: Delete event (protected)
        if created_event_id:
            self.test_delete_event(created_event_id)
        
        # Test 11: Delete non-existent event
        self.test_delete_nonexistent_event()
        
        # Test 12: Get site content (public)
        success, content = self.test_get_site_content()
        
        # Test 13: Update site content (protected)
        if self.token:
            self.test_update_site_content()
        
        # Test 14: Update site content without auth
        self.test_update_site_content_without_token()
        
        return self.generate_summary()
    
    def generate_summary(self):
        """Generate test summary"""
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests
        
        print("\n" + "=" * 60)
        print("📊 TEST SUMMARY")
        print("=" * 60)
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {failed_tests} ❌")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")
        
        return {
            "total": total_tests,
            "passed": passed_tests,
            "failed": failed_tests,
            "success_rate": (passed_tests/total_tests)*100,
            "results": self.test_results
        }

if __name__ == "__main__":
    print("Backend API Testing for Breakdance Crew Website")
    print(f"Testing against: {BACKEND_URL}")
    print(f"Admin credentials: {DEFAULT_ADMIN_USERNAME}/{DEFAULT_ADMIN_PASSWORD}")
    print()
    
    tester = BackendTester()
    summary = tester.run_all_tests()
    
    # Exit with appropriate code
    sys.exit(0 if summary["failed"] == 0 else 1)